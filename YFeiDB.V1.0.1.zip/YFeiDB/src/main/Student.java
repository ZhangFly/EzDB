package main;

public class Student {

}
